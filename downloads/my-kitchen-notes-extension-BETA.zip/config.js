// Written by tools/build-extension.mjs (beta).
var MKN_APP = "https://my-kitchen-notes-beta.pages.dev/";
var MKN_FAMILY_APP = "";
var MKN_APP_NAME = "My Kitchen Notes (BETA)";
var MKN_TAG = "beta";
