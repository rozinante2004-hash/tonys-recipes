// Written by tools/build-extension.mjs (live).
var MKN_APP = "https://mykitchennotes.community/";
var MKN_FAMILY_APP = "https://rozinante2004-hash.github.io/tonys-recipes/";
var MKN_APP_NAME = "My Kitchen Notes";
var MKN_TAG = "live";
