// Written by tools/build-extension.mjs (test).
var MKN_APP = "https://tonys-recipes-test.pages.dev/";
var MKN_FAMILY_APP = "";
var MKN_APP_NAME = "My Kitchen Notes (TEST)";
var MKN_TAG = "test";
